package uz.gita.mymemorygame.data

data class ImageData(
    val imageURL : Int,
    val amount : Int
)