package uz.gita.mymemorygame.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import uz.gita.mymemorygame.data.ImageData
import uz.gita.mymemorygame.domain.AppRepository

class GameViewModel : ViewModel() {
    private val repository = AppRepository.getRepository()

    private val _imagesLiveData = MutableLiveData<List<ImageData>>()
    val imageLiveData : LiveData<List<ImageData>> get() = _imagesLiveData

    fun loadImages(count : Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.getImagesData(count).collect {
                _imagesLiveData.postValue(it)
            }
        }
    }
}