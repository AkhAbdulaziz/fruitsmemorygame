package uz.gita.mymemorygame.ui.screen

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import by.kirich1409.viewbindingdelegate.viewBinding
import uz.gita.mymemorygame.R
import uz.gita.mymemorygame.data.ImageData
import uz.gita.mymemorygame.databinding.ScreenGameBinding
import uz.gita.mymemorygame.ui.viewmodel.GameViewModel
import uz.gita.mymemorygame.util.*

class GameScreen : Fragment(R.layout.screen_game) {
    private val binding by viewBinding(ScreenGameBinding::bind)
    private val viewModel: GameViewModel by viewModels()
    private val imageList = ArrayList<ImageView>()
    private var x = 0
    private var y = 0
    private var _height = 0
    private var _width = 0
    private var firstPos = -1
    private var secondPos = -1
    private lateinit var handler: Handler
    private var imageCount = 0
    private var isAnimated = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) = binding.scope {
        handler = Handler(Looper.getMainLooper())
        requireArguments().apply {
            x = getInt("x")
            y = getInt("y")
            imageCount = x * y
        }
        main.post {
            _height = main.height / (y + 2)
            _width = main.width / (x + 1)
            container.layoutParams.apply {
                height = y * _height
                width = x * _width
            }
            loadViews()
            viewModel.loadImages(imageCount)
        }
        viewModel.imageLiveData.observe(viewLifecycleOwner, imagesObserver)
    }

    private fun loadViews() {
        for (i in 0 until y) {
            for (j in 0 until x) {
                val image = ImageView(requireContext())
                binding.container.addView(image)
                image.layoutParams.apply {
                    height = _height
                    width = _width
                }
                image.y = i * _height * 1f
                image.x = j * _width * 1f
                val lp = image.layoutParams as RelativeLayout.LayoutParams
                lp.setMargins(4, 4, 4, 4)
                image.setImageResource(R.drawable.image_back)
                imageList.add(image)
            }
        }
    }

    private fun check() {
        val firstImageTag = imageList[firstPos].tag as ImageData
        val secondImageTag = imageList[secondPos].tag as ImageData
        if (firstImageTag.amount == secondImageTag.amount) {
            handler.postDelayed({
                timber("firstPos = $firstPos")
                imageList[firstPos].remove {
                    scaleX = 1f
                    scaleY = 1f
                }
                imageList[secondPos].remove {
                    scaleX = 1f
                    scaleY = 1f
                    imageCount -= 2
                    if (imageCount == 0) finishGame()
                    firstPos = -1
                    secondPos = -1
                    isAnimated = false
                }
            }, 250)
        } else {
            handler.postDelayed({
                imageList[firstPos].closeAnimation()
                imageList[secondPos].closeAnimation {
                    firstPos = -1
                    secondPos = -1
                    isAnimated = false
                }
            }, 250)
        }
    }

    private fun finishGame() {
        for (image in imageList)
            image.visible()
//        handler.postDelayed({
//            showToast("Finish game")
//        }, 250)
    }

    private val imagesObserver = Observer<List<ImageData>> {
        for (i in imageList.indices) {
            imageList[i].apply {
                tag = it[i]
                setOnClickListener {
                    if (isAnimated) return@setOnClickListener
                    if (firstPos == -1) {
                        firstPos = i
                        if (rotationY == 0f) {
                            this.openAnimation()
                        }
                    } else if (i != firstPos) {
                        isAnimated = true
                        secondPos = i
                        if (rotationY == 0f) this.openAnimation {
                            check()
                        }
                    }
                }
            }
        }
    }
}
