package uz.gita.mymemorygame.ui.screen

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import uz.gita.mymemorygame.R
import uz.gita.mymemorygame.databinding.ScreenLevelBinding
import uz.gita.mymemorygame.util.scope


class LevelScreen : Fragment(R.layout.screen_level) {
    private val binding by viewBinding(ScreenLevelBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) = binding.scope {
        easyButton.setOnClickListener { openGameScreen(3,4) }
        mediumButton.setOnClickListener { openGameScreen(4,5) }
        hardButton.setOnClickListener { openGameScreen(5,6) }
    }

    private fun openGameScreen(x : Int,y :Int) {
        val bundle = Bundle()
        bundle.putInt("x",x)
        bundle.putInt("y",y)
        findNavController().navigate(R.id.action_levelScreen_to_gameScreen,bundle)
    }
}