package uz.gita.fruitsmemorygame.data

data class ImageData(
    val imageURL : Int,
    val amount : Int
)